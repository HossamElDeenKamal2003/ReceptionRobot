<template>
    <div class="parent">
        <navNoAnmi />
        <div class="sidebar" :class="{ 'active': isActiveSidebar }">
            <router-link to="/allOrderslabs" style="text-decoration: underline;">All Orders</router-link>
            <router-link to="/contact">Contact</router-link>
            <router-link to="/doctorLab">Doctors</router-link>
            <router-link to="/deliveryLabs">Delivery</router-link>
            <router-link to="/financeLabs">Finance</router-link>
        </div>
        <div class="content">
            <div class="header">
                <ul ref="list">
                    <li tabindex="0"><button class="filter" @click="filterAll">All</button></li>
                    <li tabindex="0"><button class="filter" @click="filterunderway">underway</button> </li>
                    <li tabindex="0"><button class="filter" @click="filterend">End</button></li>
                    <li tabindex="0"><button class="filter" @click="update">Update</button></li>
                </ul>
                <div id="search-wrapper">
                    <i class="bi bi-search search-icon"></i>
                    <input type="text" id="search" v-model="searchTerm" @input="filterTableName" placeholder="Search">
                    <select name="" id="" v-model="selectedField">
                        <option value="id">id</option>
                        <option value="name">name</option>
                        <option value="doctor">doctor</option>
                    </select>
                </div>
            </div>
            <div class="data">
                <table style="width:100%;">
                    <tr class="head">
                        <th>ID</th>
                        <th>Name</th>
                        <th>From Doctor</th>
                        <th>Status</th>
                        <th>Modification Date</th>
                        <th>Residual</th>
                        <th>Been Paid</th>
                        <th>Price</th>
                        <th>Delete</th>
                    </tr>
                    <tr v-for="(order, index) in filteredOrders" :key="index">
                        <td>{{ order.id }}</td>
                        <td>{{ order.name }}</td>
                        <td>{{ order.doctor_name }}</td>
                        <td>{{ order.status }}</td>
                        <td>{{ order.last_updated }}</td>
                        <td><input type="text" data-order-id="{{ order.id }}" v-model="order.not_payed" disabled
                            style="border-bottom: none;" placeholder="0.00"></td>
                        <td><input type="text" data-order-id="{{ order.id }}" v-model="order.been_payed"></td>
                        <td><input type="text" data-order-id="{{ order.id }}" v-model="order.price"></td>
                        <td @click="deleteRow(order.id)"><i class="bi bi-trash"></i></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</template>

<script>
import navNoAnmi from "@/components/global/navNoAnimation.vue";
import axios from 'axios';
export default {
    name: "allOrderslabs",
    components: {
        navNoAnmi,
    },
    data() {
        return {
            selectedField: "id",
            ID: "",
            searchTerm: "",
            data: {
                name: "hossam",
                fromDoctor: "",
                status: "",
                modificationDate: "",
            },
            orders: [
                { id: "A101", name: "hossam", fromDoctor: "hoss abo kamal", status: "End", residual: "50", beenPaid: "50" },
                { name: "Bassant", status: "underway" },
            ],
            filteredOrders: [],
            filterEnd: [],
            filterUnderWay: [],
            filterForSearch: "",
            searchFilter: "",
            searchFilterType: "id",
            order_id: "",
        };
    },
    methods: {
        filterTableName() {
            if (!this.searchTerm) {
                this.filteredOrders = this.orders;
                return;
            }
            this.searchFilter = this.searchTerm.toLowerCase()
            if (this.selectedField === "id") {
                this.searchFilterType = "id"
            } else if (this.selectedField === "name") {
                this.searchFilterType = "name"
            } else if (this.selectedField === "doctor") {
                this.searchFilterType = "doctor"
            }
            this.fetchData();
        },
        filterunderway() {
            this.fetchingData = false; // Stop fetching data
            this.filterForSearch = "u"
            this.fetchData();
        },
        filterend() {
            this.fetchingData = false; // Stop fetching data
            this.filterForSearch = "e"
            this.fetchData();
        },

        filterAll() {
            this.fetchingData = true; // Resume fetching data
            this.filteredOrders = this.orders;
            this.filterForSearch = ""
            this.fetchData();
        },
        deleteRow(orderId) {
            if (!confirm("Are you sure you want to delete this order?")) {
                return; // Do nothing if user cancels
            }

            axios.patch(`http://localhost:8000/api/delete_order/${orderId}/`)
                .then(response => {
                    console.log(response);
                    // Assuming response is successful, update your local data
                    this.orders = this.orders.filter(order => order.id !== orderId);
                    this.filteredOrders = this.filteredOrders.filter(order => order.id !== orderId);
                    console.log(`Order with id ${orderId} deleted successfully.`);
                })
                .catch(error => {
                    console.error("Error deleting order:", error);
                    // Handle error here
                });
        },
        fetchData() {
            let ApiUrl;
            if (this.filterForSearch == "") {
                ApiUrl = 'http://127.0.0.1:8000/api/laboratory/all_orders/'
            } else {
                ApiUrl = 'http://127.0.0.1:8000/api/laboratory/all_orders/?status=' + this.filterForSearch
            }
            axios.get(ApiUrl)
                .then(response => {
                    this.orders = response.data;
                    this.filteredOrders = this.orders;
                    if (this.searchFilterType === "id") {
                        this.filteredOrders = this.orders.filter(order =>
                            order.id && String(order.id).includes(this.searchFilter)
                        );
                    } else if (this.searchFilterType === "name") {
                        this.filteredOrders = this.orders.filter(order =>
                            order.name && order.name.toLowerCase().includes(this.searchFilter)
                        );
                    } else if (this.searchFilterType === "doctor") {
                        this.filteredOrders = this.orders.filter(order =>
                            order.doctor_name && order.doctor_name.toLowerCase().includes(this.searchFilter)
                        );
                    }
                    this.orders.forEach(order => {
                        if (order.status === 'u') {
                            order.status = "UnderWay";
                        } else if (order.status === 'e') {
                            order.status = "End";
                        }
                    });
                })
                .catch(error => {
                    console.error("Error fetching data:", error);
                });
        },
        update() {
            this.orders.forEach(updatedOrder => {
                const orderToUpdate = this.orders.find(order => order.id === updatedOrder.id);
                if (orderToUpdate) {
                    console.log(updatedOrder.id);
                    orderToUpdate.residual = orderToUpdate.price - orderToUpdate.beenPaid;
                    console.log(updatedOrder.been_payed);
                    console.log(updatedOrder.price - updatedOrder.been_payed);
                    console.log(updatedOrder.price);
                    axios.patch(`http://localhost:8000/api/laboratory/edit_order/${updatedOrder.id}/`, {
                        been_payed: updatedOrder.been_payed,
                        not_payed: updatedOrder.price - updatedOrder.been_payed,
                        price: updatedOrder.price
                    }).then(response => {
                        console.log(`Price changed for order with id ${orderToUpdate.id}`);
                        console.log(response);
                    }).catch(error => {
                        console.error(error);
                    });

                }
            });
            this.fetchData();
        },
    },
    mounted() {
        this.fetchData();
        setInterval(() => {
            this.fetchData();
        }, 300000);
    },
    created() {
        axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
    },
    watch: {

    }
    // Other component options...
    //     watch: {
    //     orders: {
    //         handler(orders) {
    //             orders.forEach(order => {
    //                 // Find the order with the specific ID
    //                 const orderToUpdate = this.orders.find(order => order.id === this.order_id);
    //                 console.log(this.order_id);
    //                 if (orderToUpdate) {
    //                     // Only proceed if 'been_payed' or 'price' has changed
    //                     if (orderToUpdate.been_payed !== order.been_payed || orderToUpdate.price !== order.price) {
    //                         axios.post(`http://localhost:8000/api/laboratory/edit_order/${this.order_id}/`, {
    //                             been_payed: orderToUpdate.been_payed,
    //                             not_payed: order.residual // Assuming 'residual' is the field for 'not_payed'
    //                         }).then(response => {
    //                             console.log(`Price changed for order with id ${order.id}`);
    //                             console.log(response);
    //                         }).catch(error => {
    //                             console.error(error);
    //                         });
    //                     }
    //                 }
    //             });
    //         },
    //         deep: true
    //     }
    // },
};
</script>



<style scoped>
.sidebar {
    margin: 0;
    padding: 0;
    width: 200px;
    background-color: #33a1f1;
    position: fixed;
    height: 100%;
    overflow: auto;
    transition: 0.5s;
}

.sidebar a {
    display: block;
    color: white;
    padding: 16px;
    text-decoration: none;
    transition: 0.7s ease-in-out;
}


.sidebar .activate {
    background-color: blue;
}

.header {
    display: flex;
    width: 100%;
    justify-content: space-around;
    align-items: center;
    flex-wrap: wrap;
    gap: 10%;
}

input {
    text-align: center;
}

.header button {
    border: 2px solid black;
    border-radius: 50px;
    padding: 10px;
    margin-right: 50px;
    width: 150px;
    height: 44px;
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: white;
}

.header button:focus {
    color: #33a1f1;
    border: 2px solid #33a1f1;
}

.header ul {
    margin-top: 15px;
}

ul {
    list-style: none;
    font-size: 1.5em;
}

li {
    cursor: pointer;
    display: inline-block;
    margin-right: 10px;
}

td {
    font-style: bold;
}

.filter {
    border: none;
}

.filter:focus {
    color: #33a1f1;
    outline: none;
}

#search-wrapper {
    display: flex;
    border: 1px solid rgba(0, 0, 0, 0.276);
    align-items: stretch;
    border-radius: 50px;
    background-color: #fff;
    overflow: hidden;
    max-width: 400px;
}

ul li button {
    border: none;
}

#search {
    border: none;
    width: 350px;
    font-size: 15px;
}

#search:focus {
    outline: none;
}

.search-icon {
    margin: 10px;
    color: #33a1f1;
}

#search-button {
    border: none;
    cursor: pointer;
    color: #fff;
    background-color: black;
    padding: 0px 10px;
    transition: .7s ease-in-out;
}

#search-button:hover {
    background-color: white;
    color: #33a1f1;
}


.data {
    display: flex;
    justify-content: center;
    overflow: auto;
}

table {
    height: fit-content;
}

table tr {
    height: 10px;
    border-bottom: 2px #33a1f1 solid;
    margin-top: 20px;
}

.head {
    background-color: #33a1f1;
}

td i {
    cursor: pointer;
}

td i:hover {
    color: red;
}

td input {
    outline: #33a1f1;
    border-right: none;
    border-left: none;
    border-top: none;
    border-bottom: 2px solid black;
}

input:focus {
    border-bottom: blue;
}

table button {
    border: none;
}

.edit {
    text-decoration: underline;
    color: #33a1f1;
}

.sidebar {
    width: 100%;
    height: auto;
    position: relative;
}

.sidebar a {
    float: left;
}

.content {
    height: 100vh;
}

div.content {
    margin-left: 0;
}

table {
    margin-top: 15px;
}

.update:focus {
    color: black;
}
</style>
