<template>
    <div>
        <navBar />
        <div class="container">
            <div class="left-side">
            </div>
            <div class="cards">
                <div v-for="(doctor, index) in doctors" :key="index" class="card" style="width: 18rem;">
                    <div class="card-body">
                        <h5 class="card-title">{{ doctor.name }}</h5>
                        <p class="card-text">{{ doctor.description }}</p>
                        <router-link :to="'/contactEdit/' + doctor.id" class="btn btn-primary btn-sm">Show
                            Contract</router-link>
                        <button class="delete" @click="deleteCard"><i class="bi bi-trash"></i></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import navBar from "@/components/global/navBar.vue";
import axios from 'axios';
export default {
    name: "doctorLab",
    components: {
        navBar
    },
    data() {
        return {
            doctors: [
            ]
        };
    },

    mounted() {
        axios.get('http://127.0.0.1:8000/api/lab_doctors/').then(response => {
            // console.log(response.data);
            response.data.forEach(doctor => {
                if (doctor.doctorcontracts) {
                    this.doctors.push({ name: doctor.name, description: doctor.doctorcontracts.description, id: doctor.id });
                } else {
                    this.doctors.push({ name: doctor.name, description: "", id: doctor.id });
                }

            });
            // this.doctors.name = response.data.name;
            // this.doctors.id = response.data.userId;
        }).catch(error => {
            console.log(error);
        })
    },
    methods: {
        deleteCard(index) {
            this.doctors.splice(index, 1);
        }
    },
    created() {
        axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
    },
}
</script>

<style scoped>
.left-side {
    height: 100%;
    width: 4vw;
    background-color: blue;
    position: absolute;
    left: 0;
    border-radius: 15px;
    border-radius: 10px 0 0px 10px;
}

.container {
    height: 80vh;
    background-color: whitesmoke;
    margin-top: 10px;
    position: relative;
    border-radius: 10px;
    display: flex;
    justify-content: center;
    overflow: auto;
    overflow-x: hidden;
}

.cards {
    display: flex;
    justify-content: center;
    flex-wrap: wrap;
    height: min-content;
    gap: 15px;
    margin-right: -50px;
}

a {
    display: block;
}

.card-body button {
    background-color: red;
    margin-top: 15px;
}

.card-body button i:hover {
    color: white;
}
</style>
